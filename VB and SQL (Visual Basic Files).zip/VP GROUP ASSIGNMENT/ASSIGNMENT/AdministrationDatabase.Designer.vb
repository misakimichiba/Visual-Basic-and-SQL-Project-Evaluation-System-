﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdministrationDatabase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnUpdateCourse = New System.Windows.Forms.Button()
        Me.btnDeleteCourse = New System.Windows.Forms.Button()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        Me.txtCourseLecturerName = New System.Windows.Forms.TextBox()
        Me.txtCourseName = New System.Windows.Forms.TextBox()
        Me.txtCourseID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView = New System.Windows.Forms.DataGridView()
        Me.btnSearchCourse = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtLecturerID = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnSearchLecturer = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnUpdateLecturer = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnDeleteLecturer = New System.Windows.Forms.Button()
        Me.btnAddLecturer = New System.Windows.Forms.Button()
        Me.txtLecturerName = New System.Windows.Forms.TextBox()
        Me.txtLecturerCourse = New System.Windows.Forms.TextBox()
        Me.CourseReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStripForForm3 = New System.Windows.Forms.MenuStrip()
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripForForm3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdateCourse
        '
        Me.btnUpdateCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdateCourse.Location = New System.Drawing.Point(299, 385)
        Me.btnUpdateCourse.Name = "btnUpdateCourse"
        Me.btnUpdateCourse.Size = New System.Drawing.Size(89, 34)
        Me.btnUpdateCourse.TabIndex = 18
        Me.btnUpdateCourse.Text = "Update"
        Me.btnUpdateCourse.UseVisualStyleBackColor = True
        '
        'btnDeleteCourse
        '
        Me.btnDeleteCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteCourse.Location = New System.Drawing.Point(204, 385)
        Me.btnDeleteCourse.Name = "btnDeleteCourse"
        Me.btnDeleteCourse.Size = New System.Drawing.Size(89, 34)
        Me.btnDeleteCourse.TabIndex = 17
        Me.btnDeleteCourse.Text = "Delete"
        Me.btnDeleteCourse.UseVisualStyleBackColor = True
        '
        'btnAddCourse
        '
        Me.btnAddCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddCourse.Location = New System.Drawing.Point(109, 385)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(89, 34)
        Me.btnAddCourse.TabIndex = 16
        Me.btnAddCourse.Text = "Add"
        Me.btnAddCourse.UseVisualStyleBackColor = True
        '
        'txtCourseLecturerName
        '
        Me.txtCourseLecturerName.Location = New System.Drawing.Point(155, 347)
        Me.txtCourseLecturerName.Name = "txtCourseLecturerName"
        Me.txtCourseLecturerName.Size = New System.Drawing.Size(233, 20)
        Me.txtCourseLecturerName.TabIndex = 15
        '
        'txtCourseName
        '
        Me.txtCourseName.Location = New System.Drawing.Point(155, 313)
        Me.txtCourseName.Name = "txtCourseName"
        Me.txtCourseName.Size = New System.Drawing.Size(233, 20)
        Me.txtCourseName.TabIndex = 14
        '
        'txtCourseID
        '
        Me.txtCourseID.Location = New System.Drawing.Point(155, 279)
        Me.txtCourseID.Name = "txtCourseID"
        Me.txtCourseID.Size = New System.Drawing.Size(233, 20)
        Me.txtCourseID.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 344)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 23)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Lecturer Name :"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(15, 310)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 23)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Course Name :"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 276)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 23)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Course ID :"
        '
        'DataGridView
        '
        Me.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView.Location = New System.Drawing.Point(15, 28)
        Me.DataGridView.Name = "DataGridView"
        Me.DataGridView.Size = New System.Drawing.Size(373, 235)
        Me.DataGridView.TabIndex = 19
        '
        'btnSearchCourse
        '
        Me.btnSearchCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchCourse.Location = New System.Drawing.Point(14, 385)
        Me.btnSearchCourse.Name = "btnSearchCourse"
        Me.btnSearchCourse.Size = New System.Drawing.Size(89, 34)
        Me.btnSearchCourse.TabIndex = 20
        Me.btnSearchCourse.Text = "Search"
        Me.btnSearchCourse.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DataGridView)
        Me.GroupBox1.Controls.Add(Me.btnSearchCourse)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnUpdateCourse)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.btnDeleteCourse)
        Me.GroupBox1.Controls.Add(Me.txtCourseID)
        Me.GroupBox1.Controls.Add(Me.btnAddCourse)
        Me.GroupBox1.Controls.Add(Me.txtCourseName)
        Me.GroupBox1.Controls.Add(Me.txtCourseLecturerName)
        Me.GroupBox1.Location = New System.Drawing.Point(19, 34)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(405, 434)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course Profile"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtLecturerID)
        Me.GroupBox2.Controls.Add(Me.DataGridView1)
        Me.GroupBox2.Controls.Add(Me.btnSearchLecturer)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.btnUpdateLecturer)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.btnDeleteLecturer)
        Me.GroupBox2.Controls.Add(Me.btnAddLecturer)
        Me.GroupBox2.Controls.Add(Me.txtLecturerName)
        Me.GroupBox2.Controls.Add(Me.txtLecturerCourse)
        Me.GroupBox2.Location = New System.Drawing.Point(430, 34)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(405, 434)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Lecturer Profile"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 279)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(134, 23)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Lecturer ID :"
        '
        'txtLecturerID
        '
        Me.txtLecturerID.Location = New System.Drawing.Point(155, 282)
        Me.txtLecturerID.Name = "txtLecturerID"
        Me.txtLecturerID.Size = New System.Drawing.Size(233, 20)
        Me.txtLecturerID.TabIndex = 22
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(15, 28)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(373, 235)
        Me.DataGridView1.TabIndex = 19
        '
        'btnSearchLecturer
        '
        Me.btnSearchLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchLecturer.Location = New System.Drawing.Point(14, 385)
        Me.btnSearchLecturer.Name = "btnSearchLecturer"
        Me.btnSearchLecturer.Size = New System.Drawing.Size(89, 34)
        Me.btnSearchLecturer.TabIndex = 20
        Me.btnSearchLecturer.Text = "Search"
        Me.btnSearchLecturer.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(15, 310)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 23)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Lecturer Name :"
        '
        'btnUpdateLecturer
        '
        Me.btnUpdateLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdateLecturer.Location = New System.Drawing.Point(299, 385)
        Me.btnUpdateLecturer.Name = "btnUpdateLecturer"
        Me.btnUpdateLecturer.Size = New System.Drawing.Size(89, 34)
        Me.btnUpdateLecturer.TabIndex = 18
        Me.btnUpdateLecturer.Text = "Update"
        Me.btnUpdateLecturer.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 344)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(134, 23)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Course ID :"
        '
        'btnDeleteLecturer
        '
        Me.btnDeleteLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteLecturer.Location = New System.Drawing.Point(204, 385)
        Me.btnDeleteLecturer.Name = "btnDeleteLecturer"
        Me.btnDeleteLecturer.Size = New System.Drawing.Size(89, 34)
        Me.btnDeleteLecturer.TabIndex = 17
        Me.btnDeleteLecturer.Text = "Delete"
        Me.btnDeleteLecturer.UseVisualStyleBackColor = True
        '
        'btnAddLecturer
        '
        Me.btnAddLecturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddLecturer.Location = New System.Drawing.Point(109, 385)
        Me.btnAddLecturer.Name = "btnAddLecturer"
        Me.btnAddLecturer.Size = New System.Drawing.Size(89, 34)
        Me.btnAddLecturer.TabIndex = 16
        Me.btnAddLecturer.Text = "Add"
        Me.btnAddLecturer.UseVisualStyleBackColor = True
        '
        'txtLecturerName
        '
        Me.txtLecturerName.Location = New System.Drawing.Point(155, 313)
        Me.txtLecturerName.Name = "txtLecturerName"
        Me.txtLecturerName.Size = New System.Drawing.Size(233, 20)
        Me.txtLecturerName.TabIndex = 14
        '
        'txtLecturerCourse
        '
        Me.txtLecturerCourse.Location = New System.Drawing.Point(155, 347)
        Me.txtLecturerCourse.Name = "txtLecturerCourse"
        Me.txtLecturerCourse.Size = New System.Drawing.Size(233, 20)
        Me.txtLecturerCourse.TabIndex = 15
        '
        'CourseReportToolStripMenuItem
        '
        Me.CourseReportToolStripMenuItem.Name = "CourseReportToolStripMenuItem"
        Me.CourseReportToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
        Me.CourseReportToolStripMenuItem.Text = "Course Report"
        '
        'LecturerReportToolStripMenuItem
        '
        Me.LecturerReportToolStripMenuItem.Name = "LecturerReportToolStripMenuItem"
        Me.LecturerReportToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.LecturerReportToolStripMenuItem.Text = "Lecturer Report"
        '
        'MenuStripForForm3
        '
        Me.MenuStripForForm3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourseReportToolStripMenuItem, Me.LecturerReportToolStripMenuItem})
        Me.MenuStripForForm3.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripForForm3.Name = "MenuStripForForm3"
        Me.MenuStripForForm3.Size = New System.Drawing.Size(856, 24)
        Me.MenuStripForForm3.TabIndex = 23
        Me.MenuStripForForm3.Text = "MenuStrip1"
        '
        'AdministrationDatabase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(856, 476)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStripForForm3)
        Me.MainMenuStrip = Me.MenuStripForForm3
        Me.Name = "AdministrationDatabase"
        Me.Text = "that "
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripForForm3.ResumeLayout(False)
        Me.MenuStripForForm3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnUpdateCourse As Button
    Friend WithEvents btnDeleteCourse As Button
    Friend WithEvents btnAddCourse As Button
    Friend WithEvents txtCourseLecturerName As TextBox
    Friend WithEvents txtCourseName As TextBox
    Friend WithEvents txtCourseID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents btnSearchCourse As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnSearchLecturer As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents btnUpdateLecturer As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents btnDeleteLecturer As Button
    Friend WithEvents btnAddLecturer As Button
    Friend WithEvents txtLecturerName As TextBox
    Friend WithEvents txtLecturerCourse As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtLecturerID As TextBox
    Friend WithEvents CourseReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuStripForForm3 As MenuStrip
End Class
