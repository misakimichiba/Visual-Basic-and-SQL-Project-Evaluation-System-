﻿Imports System.Data.OleDb
Public Class Login
    Dim strUsername As String = ""
    Dim strPassword As String = ""
    Dim connectionString As String =
       "Provider=Microsoft.ACE.OLEDB.12.0;
        Data Source=C:\Users\Joyce\Desktop\Misaki's stuff\UNIVERSITY STUFF\INTRO TO VISUAL PROGRAMMING\VP Group Assignment (22-11-19)\Database for VP Group Assignment.accdb"
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RadStudent_CheckedChanged(sender As Object, e As EventArgs) Handles radStudent.CheckedChanged
        If radStudent.Checked = True Then
            GroupBox1.Visible = True
        Else
            GroupBox1.Visible = False
        End If
    End Sub

    Private Sub RadAdministrator_CheckedChanged(sender As Object, e As EventArgs) Handles radAdministrator.CheckedChanged
        If radAdministrator.Checked = True Then
            GroupBox1.Visible = True
        Else
            GroupBox1.Visible = False
        End If
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim cn As New OleDbConnection(connectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object based on the database connection
        cmd.CommandText = "SELECT * FROM StudentTable
                    WHERE studentName = ? AND studentPassword = ?;" 'giving SQL command into SQL object



        If txtUsername.Text = "admin" And txtPassword.Text = "admin" And radAdministrator.Checked = True Then
            Dim frm2 As New AdminMenu
            frm2.Show()
            Me.Hide()
        Else
            Try
                If radStudent.Checked = True Then
                    cmd.Parameters.AddWithValue("?", txtUsername.Text)
                    cmd.Parameters.AddWithValue("?", txtPassword.Text)
                    cn.Open()

                    cmd.Connection = cn
                    Dim dr As OleDbDataReader = cmd.ExecuteReader

                    If dr.Read Then
                        Dim frm3 As New StudentMenu
                        frm3.strUserId = txtUsername.Text
                        frm3.Show()
                        Me.Hide()
                    Else
                        MessageBox.Show("Invalid username and password for student or if you are an admin,
please select the correct radio button")
                    End If

                Else
                    MessageBox.Show("If you want to log in as a student, please select the student radio button")

                End If
                cn.Close()

            Catch ex As Exception
                ' very common for a developer to simply ignore errors, unwise.
                MessageBox.Show("Please select the correct radio button and insert the correct details")
            End Try

        End If


    End Sub
End Class
