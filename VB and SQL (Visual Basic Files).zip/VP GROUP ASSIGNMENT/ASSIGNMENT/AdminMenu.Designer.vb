﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblWelcomeAdmin = New System.Windows.Forms.Label()
        Me.btnAdminPage = New System.Windows.Forms.Button()
        Me.btnReturnToLogin = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblWelcomeAdmin
        '
        Me.lblWelcomeAdmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 39.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcomeAdmin.Location = New System.Drawing.Point(12, 158)
        Me.lblWelcomeAdmin.Name = "lblWelcomeAdmin"
        Me.lblWelcomeAdmin.Size = New System.Drawing.Size(738, 64)
        Me.lblWelcomeAdmin.TabIndex = 0
        Me.lblWelcomeAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAdminPage
        '
        Me.btnAdminPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdminPage.Location = New System.Drawing.Point(69, 237)
        Me.btnAdminPage.Name = "btnAdminPage"
        Me.btnAdminPage.Size = New System.Drawing.Size(306, 55)
        Me.btnAdminPage.TabIndex = 1
        Me.btnAdminPage.Text = "Admin Page"
        Me.btnAdminPage.UseVisualStyleBackColor = True
        '
        'btnReturnToLogin
        '
        Me.btnReturnToLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToLogin.Location = New System.Drawing.Point(381, 237)
        Me.btnReturnToLogin.Name = "btnReturnToLogin"
        Me.btnReturnToLogin.Size = New System.Drawing.Size(306, 55)
        Me.btnReturnToLogin.TabIndex = 2
        Me.btnReturnToLogin.Text = "Return To Login"
        Me.btnReturnToLogin.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(223, 298)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(306, 55)
        Me.btnQuit.TabIndex = 3
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ASSIGNMENT.My.Resources.Resources.logo3
        Me.PictureBox1.Location = New System.Drawing.Point(93, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(572, 132)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'AdminMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(764, 363)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnReturnToLogin)
        Me.Controls.Add(Me.btnAdminPage)
        Me.Controls.Add(Me.lblWelcomeAdmin)
        Me.Name = "AdminMenu"
        Me.Text = "AdminMenu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblWelcomeAdmin As Label
    Friend WithEvents btnAdminPage As Button
    Friend WithEvents btnReturnToLogin As Button
    Friend WithEvents btnQuit As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
