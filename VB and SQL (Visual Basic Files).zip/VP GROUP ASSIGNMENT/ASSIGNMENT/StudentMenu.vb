﻿Public Class StudentMenu
    Public strUserId As String = ""
    Private Sub StudentMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("Welcome " & strUserId)
        lblWelcomeStudent.Text = "Welcome, " & strUserId & "!"
    End Sub

    Private Sub BtnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Me.Close()
    End Sub

    Private Sub BtnStudentPage_Click(sender As Object, e As EventArgs) Handles btnStudentPage.Click
        Dim frmStudentPage As New StudentDatabase
        frmStudentPage.ShowDialog()
    End Sub

    Private Sub BtnReturnToLogin_Click(sender As Object, e As EventArgs) Handles btnReturnToLogin.Click
        Dim frmLogin As New Login
        frmLogin.Show()
        Me.Hide()
    End Sub
End Class