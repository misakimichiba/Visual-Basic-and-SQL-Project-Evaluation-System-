﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class StudentMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnReturnToLogin = New System.Windows.Forms.Button()
        Me.btnStudentPage = New System.Windows.Forms.Button()
        Me.lblWelcomeStudent = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(236, 308)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(306, 55)
        Me.btnQuit.TabIndex = 7
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnReturnToLogin
        '
        Me.btnReturnToLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToLogin.Location = New System.Drawing.Point(395, 247)
        Me.btnReturnToLogin.Name = "btnReturnToLogin"
        Me.btnReturnToLogin.Size = New System.Drawing.Size(306, 55)
        Me.btnReturnToLogin.TabIndex = 6
        Me.btnReturnToLogin.Text = "Return To Login"
        Me.btnReturnToLogin.UseVisualStyleBackColor = True
        '
        'btnStudentPage
        '
        Me.btnStudentPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStudentPage.Location = New System.Drawing.Point(69, 247)
        Me.btnStudentPage.Name = "btnStudentPage"
        Me.btnStudentPage.Size = New System.Drawing.Size(306, 55)
        Me.btnStudentPage.TabIndex = 5
        Me.btnStudentPage.Text = "Student Page"
        Me.btnStudentPage.UseVisualStyleBackColor = True
        '
        'lblWelcomeStudent
        '
        Me.lblWelcomeStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 39.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcomeStudent.Location = New System.Drawing.Point(9, 169)
        Me.lblWelcomeStudent.Name = "lblWelcomeStudent"
        Me.lblWelcomeStudent.Size = New System.Drawing.Size(757, 64)
        Me.lblWelcomeStudent.TabIndex = 4
        Me.lblWelcomeStudent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ASSIGNMENT.My.Resources.Resources.logo3
        Me.PictureBox1.Location = New System.Drawing.Point(99, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(572, 132)
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'StudentMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(776, 372)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblWelcomeStudent)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnStudentPage)
        Me.Controls.Add(Me.btnReturnToLogin)
        Me.Name = "StudentMenu"
        Me.Text = "StudentMenu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnQuit As Button
    Friend WithEvents btnReturnToLogin As Button
    Friend WithEvents btnStudentPage As Button
    Friend WithEvents lblWelcomeStudent As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
