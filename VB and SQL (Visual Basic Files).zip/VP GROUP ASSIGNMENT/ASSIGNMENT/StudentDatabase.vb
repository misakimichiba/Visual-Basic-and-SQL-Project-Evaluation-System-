﻿Imports System.Data.OleDb
Public Class StudentDatabase

    Public strStudentID As String = ""
    Dim connectionString As String =
       "Provider=Microsoft.ACE.OLEDB.12.0;
        Data Source=C:\Users\Joyce\Desktop\Misaki's stuff\UNIVERSITY STUFF\INTRO TO VISUAL PROGRAMMING\VP Group Assignment (22-11-19)\Database for VP Group Assignment.accdb"
    Private Sub StudentDatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
     
        loadComboBoxDataLecturer()
        loadComboBoxDataCourse()

        Dim intPunctualityCount As Integer
        For intPunctualityCount = 1 To 5
            cboPunctuality.Items.Add("1")
            intPunctualityCount += 1
            cboPunctuality.Items.Add("2")
            intPunctualityCount += 1
            cboPunctuality.Items.Add("3")
            intPunctualityCount += 1
            cboPunctuality.Items.Add("4")
            intPunctualityCount += 1
            cboPunctuality.Items.Add("5")
            intPunctualityCount += 1
        Next

        Dim intPreparationCount As Integer
        For intPreparationCount = 1 To 5
            cboPreparation.Items.Add("1")
            intPreparationCount += 1
            cboPreparation.Items.Add("2")
            intPreparationCount += 1
            cboPreparation.Items.Add("3")
            intPreparationCount += 1
            cboPreparation.Items.Add("4")
            intPreparationCount += 1
            cboPreparation.Items.Add("5")
            intPreparationCount += 1

        Next


        Dim intVoiceCount As Integer
        For intVoiceCount = 1 To 5
            cboVoice.Items.Add("1")
            intVoiceCount += 1
            cboVoice.Items.Add("2")
            intVoiceCount += 1
            cboVoice.Items.Add("3")
            intVoiceCount += 1
            cboVoice.Items.Add("4")
            intVoiceCount += 1
            cboVoice.Items.Add("5")
            intVoiceCount += 1

        Next

        Dim intQualityCount As Integer
        For intQualityCount = 1 To 5
            cboQuality.Items.Add("1")
            intQualityCount += 1
            cboQuality.Items.Add("2")
            intQualityCount += 1
            cboQuality.Items.Add("3")
            intQualityCount += 1
            cboQuality.Items.Add("4")
            intQualityCount += 1
            cboQuality.Items.Add("5")
            intQualityCount += 1

        Next

        Dim intProfessionalCount As Integer
        For intProfessionalCount = 1 To 5
            cboProfessional.Items.Add("1")
            intProfessionalCount += 1
            cboProfessional.Items.Add("2")
            intProfessionalCount += 1
            cboProfessional.Items.Add("3")
            intProfessionalCount += 1
            cboProfessional.Items.Add("4")
            intProfessionalCount += 1
            cboProfessional.Items.Add("5")
            intProfessionalCount += 1

        Next

        Dim intAttitudeCount As Integer
        For intAttitudeCount = 1 To 5
            cboAttitude.Items.Add("1")
            intAttitudeCount += 1
            cboAttitude.Items.Add("2")
            intAttitudeCount += 1
            cboAttitude.Items.Add("3")
            intAttitudeCount += 1
            cboAttitude.Items.Add("4")
            intAttitudeCount += 1
            cboAttitude.Items.Add("5")
            intAttitudeCount += 1

        Next

        Dim intAssistanceCount As Integer
        For intAssistanceCount = 1 To 5
            cboAssistance.Items.Add("1")
            intAssistanceCount += 1
            cboAssistance.Items.Add("2")
            intAssistanceCount += 1
            cboAssistance.Items.Add("3")
            intAssistanceCount += 1
            cboAssistance.Items.Add("4")
            intAssistanceCount += 1
            cboAssistance.Items.Add("5")
            intAssistanceCount += 1

        Next

        Dim intCommunicationCount As Integer
        For intCommunicationCount = 1 To 5
            cboCommunication.Items.Add("1")
            intCommunicationCount += 1
            cboCommunication.Items.Add("2")
            intCommunicationCount += 1
            cboCommunication.Items.Add("3")
            intCommunicationCount += 1
            cboCommunication.Items.Add("4")
            intCommunicationCount += 1
            cboCommunication.Items.Add("5")
            intCommunicationCount += 1

        Next
    End Sub
    Private Sub loadComboBoxDataLecturer()
        Dim cn As New OleDbConnection(connectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object based on the database connection
        cmd.CommandText = "SELECT lecturerName FROM LecturerTable" 'giving SQL command into SQL object
        Try
            cn.Open()

            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader

            While dr.Read
                cboLecturer.Items.Add(dr.Item("lecturerName"))

            End While

            cn.Close()

        Catch ex As Exception
            ' very common for a developer to simply ignore errors, unwise.
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
    Private Sub loadComboBoxDataCourse()

    End Sub
    Private Sub BtnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Me.Close()
        Login.Show()
    End Sub
    Private Function displayCourseID()
        Dim cn As New OleDbConnection(connectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object based on the database connection
        cmd.CommandText = "SELECT * FROM LecturerTable
                    WHERE lecturerName = ?;" 'giving SQL command into SQL object

        Try
            cmd.Parameters.AddWithValue("?", cboLecturer.SelectedItem)
            cn.Open()

            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader

            If dr.Read Then
                cboCourse.Items.Add(dr.Item("courseID"))
            End If

            cn.Close()



        Catch ex As Exception
            ' very common for a developer to simply ignore errors, unwise.
            MessageBox.Show(ex.ToString)
        End Try
    End Function

    Private Sub CboLecturer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboLecturer.SelectedIndexChanged
        displayCourseID()

    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtComment.Text = ""
        cboCourse.Items.Clear()
        cboLecturer.SelectedIndex = 0
        cboPunctuality.SelectedIndex = -1
        cboPreparation.SelectedIndex = -1
        cboProfessional.SelectedIndex = -1
        cboQuality.SelectedIndex = -1
        cboVoice.SelectedIndex = -1
        cboAssistance.SelectedIndex = -1
        cboAttitude.SelectedIndex = -1
        cboCommunication.SelectedIndex = -1
    End Sub

    Private Sub BtnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim strCourseId As String = ""
        Dim strLecturerName As String = ""
        Dim strComment As String = ""
        Dim intPunctuality As Integer = 0
        Dim intPreparation As Integer = 0
        Dim intVoice As Integer = 0
        Dim intQuality As Integer = 0
        Dim intProfessional As Integer = 0
        Dim intAttitude As Integer = 0
        Dim intAssistance As Integer = 0
        Dim intCommunication As Integer = 0
        Dim dblAverage As Double = 0.0
        Dim dblTotal As Double = 0.0

        Try
            strCourseId = cboCourse.SelectedItem.ToString
            strLecturerName = cboLecturer.SelectedItem.ToString
            intPunctuality = cboPunctuality.SelectedItem.ToString
            intPreparation = cboPreparation.SelectedItem.ToString
            intVoice = cboVoice.SelectedItem.ToString
            intQuality = cboQuality.SelectedItem.ToString
            intProfessional = cboProfessional.SelectedItem.ToString
            intAttitude = cboAttitude.SelectedItem.ToString
            intAssistance = cboAssistance.SelectedItem.ToString
            intCommunication = cboCommunication.SelectedItem.ToString
            strComment = txtComment.Text
            dblAverage = (intPunctuality + intPreparation + intVoice + intQuality + intProfessional + intAttitude + intAssistance + intCommunication) / 8
            dblTotal = intPunctuality + intPreparation + intVoice + intQuality + intProfessional + intAttitude + intAssistance + intCommunication


            Dim cn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand With {.Connection = cn}
            cmd.CommandText = "INSERT INTO EvaluationTable (courseID, lecturerName, punctuality, 
preparation, voice, quality, professional, attitude, assistance, communication, comment, averageMark, totalMark) 
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.Parameters.AddWithValue("?", strCourseId)
            cmd.Parameters.AddWithValue("?", strLecturerName)
            cmd.Parameters.AddWithValue("?", intPunctuality)
            cmd.Parameters.AddWithValue("?", intPreparation)
            cmd.Parameters.AddWithValue("?", intVoice)
            cmd.Parameters.AddWithValue("?", intQuality)
            cmd.Parameters.AddWithValue("?", intProfessional)
            cmd.Parameters.AddWithValue("?", intAttitude)
            cmd.Parameters.AddWithValue("?", intAssistance)
            cmd.Parameters.AddWithValue("?", intCommunication)
            cmd.Parameters.AddWithValue("?", strComment)
            cmd.Parameters.AddWithValue("?", dblAverage)
            cmd.Parameters.AddWithValue("?", dblTotal)

            Try
                cn.Open()
                cmd.ExecuteNonQuery()
                cn.Close()
                MessageBox.Show("Submit success")
            Catch ex As Exception
                MessageBox.Show("Error" & ex.ToString)
            End Try

        Catch ex As Exception
            MessageBox.Show("Please enter values into each combobox and do not leave them blank")
        End Try
    End Sub
End Class