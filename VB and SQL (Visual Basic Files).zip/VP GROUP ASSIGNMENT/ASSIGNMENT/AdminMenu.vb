﻿Public Class AdminMenu
    Private Sub AdminMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblWelcomeAdmin.Text = "Welcome, Admin!"
    End Sub

    Private Sub BtnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Me.Close()
    End Sub

    Private Sub BtnAdminPage_Click(sender As Object, e As EventArgs) Handles btnAdminPage.Click
        Dim frmAdminPage As New AdministrationDatabase
        frmAdminPage.ShowDialog()
    End Sub

    Private Sub BtnReturnToLogin_Click(sender As Object, e As EventArgs) Handles btnReturnToLogin.Click
        Dim frmLogin As New Login
        frmLogin.Show()
        Me.Hide()
    End Sub
End Class