﻿Imports System.Data.OleDb
Public Class CourseEvaluationReport
    Dim connectionString As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;
        Data Source=C:\Users\Joyce\Desktop\Misaki's stuff\UNIVERSITY STUFF\INTRO TO VISUAL PROGRAMMING\VP Group Assignment (22-11-19)\Database for VP Group Assignment.accdb"

    Private Sub CourseEvaluationReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDatabaseTableEvaluationCourse()

    End Sub

    Public Sub loadDatabaseTableEvaluationCourse()
        Dim cn As New OleDbConnection(connectionString) 'establish database connection
        Dim cmd As New OleDbCommand With {.Connection = cn} 'prepare SQL object based on the database connection
        cmd.CommandText = "SELECT MIN(totalMark) As 
            'Lowest Total (out of 60)', MAX(totalMark) As 'Highest Total (out of 60)',
            AVG(totalMark) As 'Average Total (out of 60)', courseID 
            FROM EvaluationTable GROUP BY courseId;" 'giving SQL command into SQL object
        Dim dt As New DataTable With {.TableName = "EvaluationCourse"} 'create new table in Visual Studio to store database table later
        Try
            cn.Open()
            Dim ds As New DataSet
            Dim EvaluationForCourse As New DataTable With
                        {.TableName = "EvaluationCourse"}
            ds.Tables.Add(EvaluationForCourse)
            ds.Load(cmd.ExecuteReader(),
                            LoadOption.OverwriteChanges, EvaluationForCourse)
            DataGridView.DataSource = ds.Tables("EvaluationCourse")

            cn.Close()

        Catch ex As Exception
            ' very common for a developer to simply ignore errors, unwise.
            MessageBox.Show(ex.ToString)
        End Try
    End Sub



    Private Sub BtnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Me.Close()
        AdministrationDatabase.Show()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class