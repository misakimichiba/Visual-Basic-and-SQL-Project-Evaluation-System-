﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentDatabase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtComment = New System.Windows.Forms.RichTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboCourse = New System.Windows.Forms.ComboBox()
        Me.cboLecturer = New System.Windows.Forms.ComboBox()
        Me.cboPunctuality = New System.Windows.Forms.ComboBox()
        Me.cboVoice = New System.Windows.Forms.ComboBox()
        Me.cboPreparation = New System.Windows.Forms.ComboBox()
        Me.cboQuality = New System.Windows.Forms.ComboBox()
        Me.cboProfessional = New System.Windows.Forms.ComboBox()
        Me.cboAttitude = New System.Windows.Forms.ComboBox()
        Me.cboAssistance = New System.Windows.Forms.ComboBox()
        Me.cboCommunication = New System.Windows.Forms.ComboBox()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(138, 448)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(89, 34)
        Me.btnReset.TabIndex = 27
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(43, 448)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(89, 34)
        Me.btnSubmit.TabIndex = 26
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 23)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Preparation :"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(30, 196)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 23)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Voice :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(30, 219)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 23)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Quality :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(30, 242)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 23)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Professional :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(30, 265)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 23)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = "Attitude :"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(30, 288)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(133, 23)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "Assistance :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(30, 150)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(133, 23)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Punctuality :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(-6, 347)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(359, 23)
        Me.Label8.TabIndex = 42
        Me.Label8.Text = "General Comment : Limit of 255 characters"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtComment
        '
        Me.txtComment.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtComment.Location = New System.Drawing.Point(29, 373)
        Me.txtComment.MaxLength = 255
        Me.txtComment.Name = "txtComment"
        Me.txtComment.Size = New System.Drawing.Size(324, 69)
        Me.txtComment.TabIndex = 44
        Me.txtComment.Text = ""
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(30, 311)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(133, 23)
        Me.Label9.TabIndex = 45
        Me.Label9.Text = "Communication :"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(25, 105)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(138, 23)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Course :"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(61, 82)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(102, 23)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "Lecturer :"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboCourse
        '
        Me.cboCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCourse.FormattingEnabled = True
        Me.cboCourse.Location = New System.Drawing.Point(169, 105)
        Me.cboCourse.Name = "cboCourse"
        Me.cboCourse.Size = New System.Drawing.Size(184, 21)
        Me.cboCourse.TabIndex = 51
        '
        'cboLecturer
        '
        Me.cboLecturer.BackColor = System.Drawing.Color.White
        Me.cboLecturer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLecturer.FormattingEnabled = True
        Me.cboLecturer.Location = New System.Drawing.Point(169, 82)
        Me.cboLecturer.Name = "cboLecturer"
        Me.cboLecturer.Size = New System.Drawing.Size(184, 21)
        Me.cboLecturer.TabIndex = 52
        '
        'cboPunctuality
        '
        Me.cboPunctuality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPunctuality.FormattingEnabled = True
        Me.cboPunctuality.Location = New System.Drawing.Point(169, 152)
        Me.cboPunctuality.Name = "cboPunctuality"
        Me.cboPunctuality.Size = New System.Drawing.Size(184, 21)
        Me.cboPunctuality.TabIndex = 53
        '
        'cboVoice
        '
        Me.cboVoice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboVoice.FormattingEnabled = True
        Me.cboVoice.Location = New System.Drawing.Point(169, 198)
        Me.cboVoice.Name = "cboVoice"
        Me.cboVoice.Size = New System.Drawing.Size(184, 21)
        Me.cboVoice.TabIndex = 54
        '
        'cboPreparation
        '
        Me.cboPreparation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPreparation.FormattingEnabled = True
        Me.cboPreparation.Location = New System.Drawing.Point(169, 175)
        Me.cboPreparation.Name = "cboPreparation"
        Me.cboPreparation.Size = New System.Drawing.Size(184, 21)
        Me.cboPreparation.TabIndex = 55
        '
        'cboQuality
        '
        Me.cboQuality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQuality.FormattingEnabled = True
        Me.cboQuality.Location = New System.Drawing.Point(169, 221)
        Me.cboQuality.Name = "cboQuality"
        Me.cboQuality.Size = New System.Drawing.Size(184, 21)
        Me.cboQuality.TabIndex = 56
        '
        'cboProfessional
        '
        Me.cboProfessional.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProfessional.FormattingEnabled = True
        Me.cboProfessional.Location = New System.Drawing.Point(169, 244)
        Me.cboProfessional.Name = "cboProfessional"
        Me.cboProfessional.Size = New System.Drawing.Size(184, 21)
        Me.cboProfessional.TabIndex = 57
        '
        'cboAttitude
        '
        Me.cboAttitude.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAttitude.FormattingEnabled = True
        Me.cboAttitude.Location = New System.Drawing.Point(169, 267)
        Me.cboAttitude.Name = "cboAttitude"
        Me.cboAttitude.Size = New System.Drawing.Size(184, 21)
        Me.cboAttitude.TabIndex = 58
        '
        'cboAssistance
        '
        Me.cboAssistance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAssistance.FormattingEnabled = True
        Me.cboAssistance.Location = New System.Drawing.Point(169, 290)
        Me.cboAssistance.Name = "cboAssistance"
        Me.cboAssistance.Size = New System.Drawing.Size(184, 21)
        Me.cboAssistance.TabIndex = 59
        '
        'cboCommunication
        '
        Me.cboCommunication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCommunication.FormattingEnabled = True
        Me.cboCommunication.Location = New System.Drawing.Point(169, 313)
        Me.cboCommunication.Name = "cboCommunication"
        Me.cboCommunication.Size = New System.Drawing.Size(184, 21)
        Me.cboCommunication.TabIndex = 60
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(233, 448)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(89, 34)
        Me.btnQuit.TabIndex = 61
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label12.Location = New System.Drawing.Point(13, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(364, 60)
        Me.Label12.TabIndex = 62
        Me.Label12.Text = "Please feel free to leave your rating and feedback based on the performance of le" &
    "cturer. We appreciate it."
        '
        'StudentDatabase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(374, 495)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.cboCommunication)
        Me.Controls.Add(Me.cboAssistance)
        Me.Controls.Add(Me.cboAttitude)
        Me.Controls.Add(Me.cboProfessional)
        Me.Controls.Add(Me.cboQuality)
        Me.Controls.Add(Me.cboPreparation)
        Me.Controls.Add(Me.cboVoice)
        Me.Controls.Add(Me.cboPunctuality)
        Me.Controls.Add(Me.cboLecturer)
        Me.Controls.Add(Me.cboCourse)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtComment)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.Label1)
        Me.Name = "StudentDatabase"
        Me.Text = "Feedbacks & Comments"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnReset As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtComment As RichTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents cboCourse As ComboBox
    Friend WithEvents cboLecturer As ComboBox
    Friend WithEvents cboPunctuality As ComboBox
    Friend WithEvents cboVoice As ComboBox
    Friend WithEvents cboPreparation As ComboBox
    Friend WithEvents cboQuality As ComboBox
    Friend WithEvents cboProfessional As ComboBox
    Friend WithEvents cboAttitude As ComboBox
    Friend WithEvents cboAssistance As ComboBox
    Friend WithEvents cboCommunication As ComboBox
    Friend WithEvents btnQuit As Button
    Friend WithEvents Label12 As Label
End Class
